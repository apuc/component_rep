<?php

return [
    'adminlte-module' => 'success',
];