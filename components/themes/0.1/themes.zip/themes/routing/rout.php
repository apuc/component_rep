<?php

use core\App;

App::$collector->gridView('themes', ['workspace\modules\themes\controllers\ThemesController']);