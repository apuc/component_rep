<?php

return [
    'article-module' => 'success',
];