<?php

use core\App;

App::$collector->gridView('article', ['workspace\modules\article\controllers\ArticleController']);