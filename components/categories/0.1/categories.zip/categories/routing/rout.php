<?php

use core\App;

App::$collector->gridView('categories', ['workspace\modules\categories\controllers\CategoriesController']);