<?php

return [
    'categories-module' => 'success',
];