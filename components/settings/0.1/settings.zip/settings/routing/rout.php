<?php

use core\App;

App::$collector->gridView('settings', ['workspace\modules\settings\controllers\SettingsController']);