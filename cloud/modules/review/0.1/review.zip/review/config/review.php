<?php

return [
    'review-module' => 'success',
];