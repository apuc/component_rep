<?php

namespace workspace\modules\review;


use core\App;

class Review
{
    public static function run()
    {
        $config['adminLeftMenu'] = [
            [
                'title' => 'Review',
                'url' => '/admin/review',
                'icon' => '<i class="nav-icon fa fa-file"></i>',
            ],
        ];

        App::mergeConfig($config);
    }
}