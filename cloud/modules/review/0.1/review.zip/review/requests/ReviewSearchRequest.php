<?php


namespace workspace\modules\review\requests;


use core\RequestSearch;

/**
 * Class ReviewSearchRequest
 * @package workspace\modules\review\requests
 *
 * @property int unsigned id
 * @property int unsigned tour_id
 * @property varchar(255) author
 * @property text review
 * @property timestamp created_at
 * @property timestamp updated_at
 */

class ReviewSearchRequest extends RequestSearch
{
    public $id;
    public $tour_id;
    public $author;
    public $review;
    public $created_at;
    public $updated_at;


    public function rules()
    {
        return [];
    }
}