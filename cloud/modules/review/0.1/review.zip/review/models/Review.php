<?php


namespace workspace\modules\review\models;


use Illuminate\Database\Eloquent\Model;
use workspace\modules\review\requests\ReviewSearchRequest;

class Review extends Model
{
    protected $table = "review";

    public $fillable = ['tour_id', 'author', 'review', 'created_at', 'updated_at'];

    public function _save()
    {
            $this->tour_id = $_POST["tour_id"];
            $this->author = $_POST["author"];
            $this->review = $_POST["review"];

        $this->save();
    }

    /**
     * @param ReviewSearchRequest $request
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function search(ReviewSearchRequest $request)
    {
        $query = self::query();

        if($request->id)
            $query->where('id', 'LIKE', "%$request->id%");

        if($request->tour_id)
            $query->where('tour_id', 'LIKE', "%$request->tour_id%");

        if($request->author)
            $query->where('author', 'LIKE', "%$request->author%");

        if($request->review)
            $query->where('review', 'LIKE', "%$request->review%");

        if($request->created_at)
            $query->where('created_at', 'LIKE', "%$request->created_at%");

        if($request->updated_at)
            $query->where('updated_at', 'LIKE', "%$request->updated_at%");


        return $query->get();
    }
}