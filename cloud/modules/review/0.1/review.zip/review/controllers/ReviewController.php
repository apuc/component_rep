<?php


namespace workspace\modules\review\controllers;


use core\App;
use core\Controller;
use workspace\modules\review\models\Review;
use workspace\modules\review\requests\ReviewSearchRequest;

class ReviewController extends Controller
{
    protected function init()
    {
        $this->viewPath = '/modules/review/views/';
        $this->layoutPath = App::$config['adminLayoutPath'];
        App::$breadcrumbs->addItem(['text' => 'AdminPanel', 'url' => 'adminlte']);
        App::$breadcrumbs->addItem(['text' => 'Review', 'url' => 'admin/review']);
    }

    public function actionIndex()
    {
        $request = new ReviewSearchRequest();
        $model = Review::search($request);

        $options = $this->setOptions();

        return $this->render('review/index.tpl', ['h1' => 'Review', 'model' => $model, 'options' => $options]);
    }

    public function actionView($id)
    {
        $model = Review::where('id', $id)->first();

        $options = $this->setOptions();

        return $this->render('review/view.tpl', ['model' => $model, 'options' => $options]);
    }

    public function actionStore()
    {
        if($this->validation()) {
            $model = new Review();
            $model->_save();

            $this->redirect('admin/review');
        } else
            return $this->render('review/store.tpl', ['h1' => 'Добавить']);
    }

    public function actionEdit($id)
    {
        $model = Review::where('id', $id)->first();

        if($this->validation()) {
            $model->_save();

            $this->redirect('admin/review');
        } else
            return $this->render('review/edit.tpl', ['h1' => 'Редактировать: ', 'model' => $model]);
    }

    public function actionDelete()
    {
        Review::where('id', $_POST['id'])->delete();
    }

    public function setOptions()
    {
        return [
            'serial' => '#',
            'fields' => [
                'id' => 'Id',
                'tour_id' => 'Tour_id',
                'author' => 'Author',
                'review' => 'Review',
                'created_at' => 'Created_at',
                'updated_at' => 'Updated_at',
            ],
            'baseUri' => 'review'
        ];
   }

   public function validation()
   {
       return (isset($_POST["tour_id"]) && isset($_POST["author"]) && isset($_POST["review"])) ? true : false;
   }
}