<?php


namespace workspace\modules\plan\models;


use Illuminate\Database\Eloquent\Model;
use workspace\modules\plan\requests\PlanSearchRequest;

class Plan extends Model
{
    protected $table = "plan";

    public $fillable = ['tour_id', 'date', 'info', 'day', 'description', 'created_at', 'updated_at'];

    public function _save()
    {
            $this->tour_id = $_POST["tour_id"];
            $this->date = $_POST["date"];
            $this->info = $_POST["info"];
            $this->day = $_POST["day"];
            $this->description = $_POST["description"];

        $this->save();
    }

    /**
     * @param PlanSearchRequest $request
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function search(PlanSearchRequest $request)
    {
        $query = self::query();

        if($request->id)
            $query->where('id', 'LIKE', "%$request->id%");

        if($request->tour_id)
            $query->where('tour_id', 'LIKE', "%$request->tour_id%");

        if($request->date)
            $query->where('date', 'LIKE', "%$request->date%");

        if($request->info)
            $query->where('info', 'LIKE', "%$request->info%");

        if($request->day)
            $query->where('day', 'LIKE', "%$request->day%");

        if($request->description)
            $query->where('description', 'LIKE', "%$request->description%");

        if($request->created_at)
            $query->where('created_at', 'LIKE', "%$request->created_at%");

        if($request->updated_at)
            $query->where('updated_at', 'LIKE', "%$request->updated_at%");


        return $query->get();
    }
}