<?php

namespace workspace\modules\plan;


use core\App;

class Plan
{
    public static function run()
    {
        $config['adminLeftMenu'] = [
            [
                'title' => 'Plan',
                'url' => '/admin/plan',
                'icon' => '<i class="nav-icon fa fa-file"></i>',
            ],
        ];

        App::mergeConfig($config);
    }
}