<?php


namespace workspace\modules\plan\controllers;


use core\App;
use core\Controller;
use workspace\modules\plan\models\Plan;
use workspace\modules\plan\requests\PlanSearchRequest;

class PlanController extends Controller
{
    protected function init()
    {
        $this->viewPath = '/modules/plan/views/';
        $this->layoutPath = App::$config['adminLayoutPath'];
        App::$breadcrumbs->addItem(['text' => 'AdminPanel', 'url' => 'adminlte']);
        App::$breadcrumbs->addItem(['text' => 'Plan', 'url' => 'admin/plan']);
    }

    public function actionIndex()
    {
        $request = new PlanSearchRequest();
        $model = Plan::search($request);

        $options = $this->setOptions();

        return $this->render('plan/index.tpl', ['h1' => 'Plan', 'model' => $model, 'options' => $options]);
    }

    public function actionView($id)
    {
        $model = Plan::where('id', $id)->first();

        $options = $this->setOptions();

        return $this->render('plan/view.tpl', ['model' => $model, 'options' => $options]);
    }

    public function actionStore()
    {
        if($this->validation()) {
            $model = new Plan();
            $model->_save();

            $this->redirect('admin/plan');
        } else
            return $this->render('plan/store.tpl', ['h1' => 'Добавить']);
    }

    public function actionEdit($id)
    {
        $model = Plan::where('id', $id)->first();

        if($this->validation()) {
            $model->_save();

            $this->redirect('admin/plan');
        } else
            return $this->render('plan/edit.tpl', ['h1' => 'Редактировать: ', 'model' => $model]);
    }

    public function actionDelete()
    {
        Plan::where('id', $_POST['id'])->delete();
    }

    public function setOptions()
    {
        return [
            'serial' => '#',
            'fields' => [
                'id' => 'Id',
                'tour_id' => 'Tour_id',
                'date' => 'Date',
                'info' => 'Info',
                'day' => 'Day',
                'description' => 'Description',
                'created_at' => 'Created_at',
                'updated_at' => 'Updated_at',
            ],
            'baseUri' => 'plan'
        ];
   }

   public function validation()
   {
       return (isset($_POST["tour_id"]) && isset($_POST["date"]) && isset($_POST["info"]) && isset($_POST["day"]) && isset($_POST["description"])) ? true : false;
   }
}