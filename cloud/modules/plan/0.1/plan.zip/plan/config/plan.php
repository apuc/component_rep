<?php

return [
    'plan-module' => 'success',
];