<?php


namespace workspace\modules\plan\requests;


use core\RequestSearch;

/**
 * Class PlanSearchRequest
 * @package workspace\modules\plan\requests
 *
 * @property int unsigned id
 * @property int unsigned tour_id
 * @property varchar(255) date
 * @property text info
 * @property int day
 * @property text description
 * @property timestamp created_at
 * @property timestamp updated_at
 */

class PlanSearchRequest extends RequestSearch
{
    public $id;
    public $tour_id;
    public $date;
    public $info;
    public $day;
    public $description;
    public $created_at;
    public $updated_at;


    public function rules()
    {
        return [];
    }
}