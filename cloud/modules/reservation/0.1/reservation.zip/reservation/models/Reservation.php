<?php


namespace workspace\modules\reservation\models;


use Illuminate\Database\Eloquent\Model;
use workspace\modules\reservation\requests\ReservationSearchRequest;

class Reservation extends Model
{
    protected $table = "reservation";

    public $fillable = ['tour_id', 'name', 'phone', 'email', 'created_at', 'updated_at'];

    public function _save()
    {
            $this->tour_id = $_POST["tour_id"];
            $this->name = $_POST["name"];
            $this->phone = $_POST["phone"];
            $this->email = $_POST["email"];

        $this->save();
    }

    /**
     * @param ReservationSearchRequest $request
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function search(ReservationSearchRequest $request)
    {
        $query = self::query();

        if($request->id)
            $query->where('id', 'LIKE', "%$request->id%");

        if($request->tour_id)
            $query->where('tour_id', 'LIKE', "%$request->tour_id%");

        if($request->name)
            $query->where('name', 'LIKE', "%$request->name%");

        if($request->phone)
            $query->where('phone', 'LIKE', "%$request->phone%");

        if($request->email)
            $query->where('email', 'LIKE', "%$request->email%");

        if($request->created_at)
            $query->where('created_at', 'LIKE', "%$request->created_at%");

        if($request->updated_at)
            $query->where('updated_at', 'LIKE', "%$request->updated_at%");


        return $query->get();
    }
}