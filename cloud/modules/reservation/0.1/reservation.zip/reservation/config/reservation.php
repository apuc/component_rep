<?php

return [
    'reservation-module' => 'success',
];