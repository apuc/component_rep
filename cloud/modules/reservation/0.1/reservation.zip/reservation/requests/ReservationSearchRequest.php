<?php


namespace workspace\modules\reservation\requests;


use core\RequestSearch;

/**
 * Class ReservationSearchRequest
 * @package workspace\modules\reservation\requests
 *
 * @property int unsigned id
 * @property int unsigned tour_id
 * @property varchar(255) name
 * @property varchar(255) phone
 * @property varchar(255) email
 * @property timestamp created_at
 * @property timestamp updated_at
 */

class ReservationSearchRequest extends RequestSearch
{
    public $id;
    public $tour_id;
    public $name;
    public $phone;
    public $email;
    public $created_at;
    public $updated_at;


    public function rules()
    {
        return [];
    }
}