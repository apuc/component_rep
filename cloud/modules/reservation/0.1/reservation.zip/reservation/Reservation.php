<?php

namespace workspace\modules\reservation;


use core\App;

class Reservation
{
    public static function run()
    {
        $config['adminLeftMenu'] = [
            [
                'title' => 'Reservation',
                'url' => '/admin/reservation',
                'icon' => '<i class="nav-icon fa fa-file"></i>',
            ],
        ];

        App::mergeConfig($config);
    }
}