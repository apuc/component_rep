<?php


namespace workspace\modules\reservation\controllers;


use core\App;
use core\Controller;
use workspace\modules\reservation\models\Reservation;
use workspace\modules\reservation\requests\ReservationSearchRequest;

class ReservationController extends Controller
{
    protected function init()
    {
        $this->viewPath = '/modules/reservation/views/';
        $this->layoutPath = App::$config['adminLayoutPath'];
        App::$breadcrumbs->addItem(['text' => 'AdminPanel', 'url' => 'adminlte']);
        App::$breadcrumbs->addItem(['text' => 'Reservation', 'url' => 'admin/reservation']);
    }

    public function actionIndex()
    {
        $request = new ReservationSearchRequest();
        $model = Reservation::search($request);

        $options = $this->setOptions();

        return $this->render('reservation/index.tpl', ['h1' => 'Reservation', 'model' => $model, 'options' => $options]);
    }

    public function actionView($id)
    {
        $model = Reservation::where('id', $id)->first();

        $options = $this->setOptions();

        return $this->render('reservation/view.tpl', ['model' => $model, 'options' => $options]);
    }

    public function actionStore()
    {
        if($this->validation()) {
            $model = new Reservation();
            $model->_save();

            $this->redirect('admin/reservation');
        } else
            return $this->render('reservation/store.tpl', ['h1' => 'Добавить']);
    }

    public function actionEdit($id)
    {
        $model = Reservation::where('id', $id)->first();

        if($this->validation()) {
            $model->_save();

            $this->redirect('admin/reservation');
        } else
            return $this->render('reservation/edit.tpl', ['h1' => 'Редактировать: ', 'model' => $model]);
    }

    public function actionDelete()
    {
        Reservation::where('id', $_POST['id'])->delete();
    }

    public function setOptions()
    {
        return [
            'serial' => '#',
            'fields' => [
                'id' => 'Id',
                'tour_id' => 'Tour_id',
                'name' => 'Name',
                'phone' => 'Phone',
                'email' => 'Email',
                'created_at' => 'Created_at',
                'updated_at' => 'Updated_at',
            ],
            'baseUri' => 'reservation'
        ];
   }

   public function validation()
   {
       return (isset($_POST["tour_id"]) && isset($_POST["name"]) && isset($_POST["phone"]) && isset($_POST["email"])) ? true : false;
   }
}