<?php


namespace workspace\modules\themes\requests;


use core\RequestSearch;

class ThemesSearchRequest extends RequestSearch
{

}