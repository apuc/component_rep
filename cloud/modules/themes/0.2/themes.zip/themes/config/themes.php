<?php

return [
    'themes-module' => 'success',
];