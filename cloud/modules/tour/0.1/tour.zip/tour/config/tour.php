<?php

return [
    'tour-module' => 'success',
];