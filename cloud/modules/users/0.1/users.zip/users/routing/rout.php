<?php

use core\App;

App::$collector->gridView('users', ['workspace\modules\users\controllers\UsersController']);