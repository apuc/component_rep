<?php


return [
    'v5_classic' => [
        'cdn' => 'https://cdn.ckeditor.com/ckeditor5/20.0.0/classic/ckeditor.js',
        'view' => 'editor.tpl'
    ],
    'v4_full' => [
        'cdn' => 'https://cdn.ckeditor.com/4.14.1/full-all/ckeditor.js',
        'view' => 'full_editor.tpl'
    ]
];