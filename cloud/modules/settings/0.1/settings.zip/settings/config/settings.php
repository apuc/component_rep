<?php

return [
    'settings-module' => 'success',
];