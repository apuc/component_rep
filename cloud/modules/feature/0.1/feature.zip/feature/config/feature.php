<?php

return [
    'feature-module' => 'success',
];