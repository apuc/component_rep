<?php

return [
    'frontend-module' => 'success',
];