<?php


namespace workspace\modules\image\models;


use Illuminate\Database\Eloquent\Model;
use workspace\modules\image\requests\ImageSearchRequest;

class Image extends Model
{
    protected $table = "image";

    public $fillable = ['image', 'created_at', 'updated_at'];

    public function _save()
    {
            $this->image = $_POST["image"];

        $this->save();
    }

    /**
     * @param ImageSearchRequest $request
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function search(ImageSearchRequest $request)
    {
        $query = self::query();

        if($request->id)
            $query->where('id', 'LIKE', "%$request->id%");

        if($request->image)
            $query->where('image', 'LIKE', "%$request->image%");

        if($request->created_at)
            $query->where('created_at', 'LIKE', "%$request->created_at%");

        if($request->updated_at)
            $query->where('updated_at', 'LIKE', "%$request->updated_at%");


        return $query->get();
    }
}