<?php


namespace workspace\modules\image\requests;


use core\RequestSearch;

/**
 * Class ImageSearchRequest
 * @package workspace\modules\image\requests
 *
 * @property int unsigned id
 * @property varchar(255) image
 * @property timestamp created_at
 * @property timestamp updated_at
 */

class ImageSearchRequest extends RequestSearch
{
    public $id;
    public $image;
    public $created_at;
    public $updated_at;


    public function rules()
    {
        return [];
    }
}