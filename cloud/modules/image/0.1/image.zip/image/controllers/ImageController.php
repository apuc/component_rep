<?php


namespace workspace\modules\image\controllers;


use core\App;
use core\Controller;
use workspace\modules\image\models\Image;
use workspace\modules\image\requests\ImageSearchRequest;

class ImageController extends Controller
{
    protected function init()
    {
        $this->viewPath = '/modules/image/views/';
        $this->layoutPath = App::$config['adminLayoutPath'];
        App::$breadcrumbs->addItem(['text' => 'AdminPanel', 'url' => 'adminlte']);
        App::$breadcrumbs->addItem(['text' => 'Image', 'url' => 'admin/image']);
    }

    public function actionIndex()
    {
        $request = new ImageSearchRequest();
        $model = Image::search($request);

        $options = $this->setOptions();

        return $this->render('image/index.tpl', ['h1' => 'Image', 'model' => $model, 'options' => $options]);
    }

    public function actionView($id)
    {
        $model = Image::where('id', $id)->first();

        $options = $this->setOptions();

        return $this->render('image/view.tpl', ['model' => $model, 'options' => $options]);
    }

    public function actionStore()
    {
        if($this->validation()) {
            $model = new Image();
            $model->_save();

            $this->redirect('admin/image');
        } else
            return $this->render('image/store.tpl', ['h1' => 'Добавить']);
    }

    public function actionEdit($id)
    {
        $model = Image::where('id', $id)->first();

        if($this->validation()) {
            $model->_save();

            $this->redirect('admin/image');
        } else
            return $this->render('image/edit.tpl', ['h1' => 'Редактировать: ', 'model' => $model]);
    }

    public function actionDelete()
    {
        Image::where('id', $_POST['id'])->delete();
    }

    public function setOptions()
    {
        return [
            'serial' => '#',
            'fields' => [
                'id' => 'Id',
                'image' => 'Image',
                'created_at' => 'Created_at',
                'updated_at' => 'Updated_at',
            ],
            'baseUri' => 'image'
        ];
   }

   public function validation()
   {
       return (isset($_POST["image"])) ? true : false;
   }
}