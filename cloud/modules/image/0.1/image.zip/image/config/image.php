<?php

return [
    'image-module' => 'success',
];